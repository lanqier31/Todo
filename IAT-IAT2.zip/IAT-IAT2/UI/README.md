# VFT
Victorinox For Test 这是一个web版的自动化测试平台，兼容
- [x] Web UI自动化
- [x] API 接口自动化
- [ ] APP UI自动化（待开发）

详情见：[基于 Jmeter 的 web 端接口自动化测试平台](https://testerhome.com/topics/17986)
更多的测试技术及工具使用，欢迎进群交流：
![](https://testerhome.com/uploads/photo/2019/80beba6b-1412-45a2-8a9d-394da51a63fb.jpg!large)
