/* eslint-disable react/prefer-stateless-function */
import React, { PureComponent } from 'react';

export default class Devtest extends PureComponent {
  render() {
    return <div>system自测试页面</div>;
  }
}
