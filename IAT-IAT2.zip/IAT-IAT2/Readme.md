# IAT
是一个Web版的接口自动化用例及测试任务管理平台，底层基于jmeter去执行生成的测试脚本。

这是一个web版的接口测试平台，旨在“简单配置、系统运行”的去做互联网接口测试。

详情见：[基于 Jmeter 的 web 端接口自动化测试平台](https://testerhome.com/topics/17986)
更多的测试技术及工具使用，欢迎进群交流：
![](https://testerhome.com/uploads/photo/2019/80beba6b-1412-45a2-8a9d-394da51a63fb.jpg!large)

## 项目目录
下面是整个项目的目录结构。

```bash
├── Server                   # 服务端代码
├── UI                       # 前端代码
└── README.md
```
